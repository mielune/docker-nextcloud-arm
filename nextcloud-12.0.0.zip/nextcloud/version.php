<?php 
$OC_Version = array(12,0,0,29);
$OC_VersionString = '12.0.0';
$OC_Edition = '';
$OC_Channel = 'stable';
$OC_VersionCanBeUpgradedFrom = array (
  'nextcloud' => 
  array (
    '11.0' => true,
    '12.0' => true,
  ),
  'owncloud' => 
  array (
    '10.0.0.12' => true,
  ),
);
$OC_Build = '2017-05-22T08:27:00+00:00 98e26f8b5c8b238e7f3556e900c524ce78bde95a';
$vendor = 'nextcloud';
